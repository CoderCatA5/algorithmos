
import Clock from "./components/Clock";
import Grid from "./components/Grid";
import Display from "./components/Display";
function App() {
  return (
    <div>
      <Clock/>
      <Grid/>
      <Display/>

    </div>
    
  );
}

export default App;
