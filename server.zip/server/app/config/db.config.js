//use own mongodb url here
module.exports = {
  url: "mongodb+srv://algos:algos@cluster0.ucxlw.mongodb.net/algorithmos?retryWrites=true&w=majority" 
};
