module.exports = {
  url: "mongodb+srv://algos:algos@cluster0.ucxlw.mongodb.net/myFirstDatabase?retryWrites=true&w=majority" 
};
